from flask import Flask, render_template, request, redirect, url_for, send_file, flash, jsonify
import pandas as pd
import os
from datetime import datetime
from fpdf import FPDF
from fpdf.enums import XPos, YPos
import io

app = Flask(__name__)
app.secret_key = 'invoice-tracker-secret-key'
app.jinja_env.globals['enumerate'] = enumerate

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')

def get_path(filename):
    return os.path.join(DATA_DIR, filename)

def initialize_system():
    os.makedirs(DATA_DIR, exist_ok=True)
    files = {
        'clients.csv': ['client_id', 'name', 'email', 'phone', 'address'],
        'invoices.csv': ['invoice_id', 'client_id', 'total_amount', 'status', 'date', 'due_date', 'notes'],
        'invoice_items.csv': ['invoice_id', 'description', 'quantity', 'price', 'line_total']
    }
    for file, columns in files.items():
        path = get_path(file)
        if not os.path.exists(path):
            pd.DataFrame(columns=columns).to_csv(path, index=False)

initialize_system()

# ─── HELPERS ───────────────────────────────────────────────────────────────────

def read_csv(name):
    return pd.read_csv(get_path(name))

def write_csv(df, name):
    df.to_csv(get_path(name), index=False)

# ─── DASHBOARD ─────────────────────────────────────────────────────────────────

@app.route('/')
def dashboard():
    invoices = read_csv('invoices.csv')
    clients  = read_csv('clients.csv')

    total_revenue     = float(invoices[invoices['status'] == 'Paid']['total_amount'].sum())
    total_outstanding = float(invoices[invoices['status'] == 'Unpaid']['total_amount'].sum())
    total_invoices    = len(invoices)
    total_clients     = len(clients)
    collection_rate   = (total_revenue / (total_revenue + total_outstanding) * 100) if (total_revenue + total_outstanding) > 0 else 0

    recent = invoices.tail(5).merge(clients[['client_id', 'name']], on='client_id', how='left')
    recent = recent.sort_values('date', ascending=False).to_dict('records')

    return render_template('dashboard.html',
        total_revenue=total_revenue,
        total_outstanding=total_outstanding,
        total_invoices=total_invoices,
        total_clients=total_clients,
        collection_rate=round(collection_rate, 1),
        recent_invoices=recent
    )

# ─── CLIENTS ───────────────────────────────────────────────────────────────────

@app.route('/clients')
def clients():
    df = read_csv('clients.csv')
    invoices = read_csv('invoices.csv')
    client_list = df.to_dict('records')
    for c in client_list:
        inv = invoices[invoices['client_id'] == c['client_id']]
        c['invoice_count'] = len(inv)
        c['total_billed'] = float(inv['total_amount'].sum())
    return render_template('clients.html', clients=client_list)

@app.route('/clients/add', methods=['GET', 'POST'])
def add_client():
    if request.method == 'POST':
        df = read_csv('clients.csv')
        new_id = int(df['client_id'].max() + 1) if len(df) > 0 else 1
        new_row = pd.DataFrame([[new_id,
                                  request.form['name'],
                                  request.form['email'],
                                  request.form.get('phone', ''),
                                  request.form.get('address', '')]],
                               columns=['client_id', 'name', 'email', 'phone', 'address'])
        df = pd.concat([df, new_row], ignore_index=True)
        write_csv(df, 'clients.csv')
        flash(f"Client '{request.form['name']}' added successfully!", 'success')
        return redirect(url_for('clients'))
    return render_template('client_form.html', client=None)

@app.route('/clients/edit/<int:client_id>', methods=['GET', 'POST'])
def edit_client(client_id):
    df = read_csv('clients.csv')
    if request.method == 'POST':
        df.loc[df['client_id'] == client_id, 'name']    = request.form['name']
        df.loc[df['client_id'] == client_id, 'email']   = request.form['email']
        df.loc[df['client_id'] == client_id, 'phone']   = request.form.get('phone', '')
        df.loc[df['client_id'] == client_id, 'address'] = request.form.get('address', '')
        write_csv(df, 'clients.csv')
        flash('Client updated!', 'success')
        return redirect(url_for('clients'))
    client = df[df['client_id'] == client_id].iloc[0].to_dict()
    return render_template('client_form.html', client=client)

@app.route('/clients/delete/<int:client_id>', methods=['POST'])
def delete_client(client_id):
    df = read_csv('clients.csv')
    df = df[df['client_id'] != client_id]
    write_csv(df, 'clients.csv')
    flash('Client deleted.', 'info')
    return redirect(url_for('clients'))

# ─── INVOICES ──────────────────────────────────────────────────────────────────

@app.route('/invoices')
def invoices():
    inv = read_csv('invoices.csv')
    clients = read_csv('clients.csv')
    status_filter = request.args.get('status', 'all')
    if status_filter != 'all':
        inv = inv[inv['status'] == status_filter]
    merged = inv.merge(clients[['client_id', 'name']], on='client_id', how='left')
    merged = merged.sort_values('date', ascending=False)
    return render_template('invoices.html', invoices=merged.to_dict('records'), status_filter=status_filter)

@app.route('/invoices/create', methods=['GET', 'POST'])
def create_invoice():
    clients = read_csv('clients.csv')
    if request.method == 'POST':
        inv_df = read_csv('invoices.csv')
        inv_id = f"INV-{len(inv_df) + 101}"
        date_today = datetime.now().strftime("%Y-%m-%d")
        due_date = request.form.get('due_date', '')
        new_inv = pd.DataFrame([[inv_id,
                                  int(request.form['client_id']),
                                  0.0,
                                  'Unpaid',
                                  date_today,
                                  due_date,
                                  request.form.get('notes', '')]],
                               columns=['invoice_id', 'client_id', 'total_amount', 'status', 'date', 'due_date', 'notes'])
        inv_df = pd.concat([inv_df, new_inv], ignore_index=True)
        write_csv(inv_df, 'invoices.csv')
        flash(f'Invoice {inv_id} created! Add line items below.', 'success')
        return redirect(url_for('invoice_detail', invoice_id=inv_id))
    return render_template('invoice_form.html', clients=clients.to_dict('records'))

@app.route('/invoices/<invoice_id>')
def invoice_detail(invoice_id):
    inv_df   = read_csv('invoices.csv')
    clients  = read_csv('clients.csv')
    items_df = read_csv('invoice_items.csv')

    inv  = inv_df[inv_df['invoice_id'] == invoice_id].iloc[0].to_dict()
    client = clients[clients['client_id'] == inv['client_id']].iloc[0].to_dict()
    items  = items_df[items_df['invoice_id'] == invoice_id].to_dict('records')

    return render_template('invoice_detail.html', invoice=inv, client=client, items=items)

@app.route('/invoices/<invoice_id>/add_item', methods=['POST'])
def add_item(invoice_id):
    qty   = float(request.form['quantity'])
    price = float(request.form['price'])
    line_total = qty * price

    items_df = read_csv('invoice_items.csv')
    new_item = pd.DataFrame([[invoice_id,
                               request.form['description'],
                               qty, price, line_total]],
                            columns=['invoice_id', 'description', 'quantity', 'price', 'line_total'])
    items_df = pd.concat([items_df, new_item], ignore_index=True)
    write_csv(items_df, 'invoice_items.csv')

    # Recalculate total
    inv_df = read_csv('invoices.csv')
    new_total = items_df[items_df['invoice_id'] == invoice_id]['line_total'].sum()
    inv_df.loc[inv_df['invoice_id'] == invoice_id, 'total_amount'] = new_total
    write_csv(inv_df, 'invoices.csv')

    flash('Item added!', 'success')
    return redirect(url_for('invoice_detail', invoice_id=invoice_id))

@app.route('/invoices/<invoice_id>/delete_item/<int:item_index>', methods=['POST'])
def delete_item(invoice_id, item_index):
    items_df = read_csv('invoice_items.csv')
    inv_items = items_df[items_df['invoice_id'] == invoice_id]
    drop_idx = inv_items.index[item_index]
    items_df = items_df.drop(drop_idx).reset_index(drop=True)
    write_csv(items_df, 'invoice_items.csv')

    inv_df = read_csv('invoices.csv')
    new_total = items_df[items_df['invoice_id'] == invoice_id]['line_total'].sum()
    inv_df.loc[inv_df['invoice_id'] == invoice_id, 'total_amount'] = new_total
    write_csv(inv_df, 'invoices.csv')

    flash('Item removed.', 'info')
    return redirect(url_for('invoice_detail', invoice_id=invoice_id))

@app.route('/invoices/<invoice_id>/mark_paid', methods=['POST'])
def mark_paid(invoice_id):
    inv_df = read_csv('invoices.csv')
    inv_df.loc[inv_df['invoice_id'] == invoice_id, 'status'] = 'Paid'
    write_csv(inv_df, 'invoices.csv')
    flash(f'{invoice_id} marked as Paid!', 'success')
    return redirect(url_for('invoice_detail', invoice_id=invoice_id))

@app.route('/invoices/<invoice_id>/mark_unpaid', methods=['POST'])
def mark_unpaid(invoice_id):
    inv_df = read_csv('invoices.csv')
    inv_df.loc[inv_df['invoice_id'] == invoice_id, 'status'] = 'Unpaid'
    write_csv(inv_df, 'invoices.csv')
    flash(f'{invoice_id} marked as Unpaid.', 'info')
    return redirect(url_for('invoice_detail', invoice_id=invoice_id))

@app.route('/invoices/<invoice_id>/delete', methods=['POST'])
def delete_invoice(invoice_id):
    inv_df = read_csv('invoices.csv')
    inv_df = inv_df[inv_df['invoice_id'] != invoice_id]
    write_csv(inv_df, 'invoices.csv')
    items_df = read_csv('invoice_items.csv')
    items_df = items_df[items_df['invoice_id'] != invoice_id]
    write_csv(items_df, 'invoice_items.csv')
    flash(f'{invoice_id} deleted.', 'info')
    return redirect(url_for('invoices'))

# ─── PDF GENERATION ────────────────────────────────────────────────────────────

@app.route('/invoices/<invoice_id>/pdf')
def generate_pdf(invoice_id):
    invoices = read_csv('invoices.csv')
    items    = read_csv('invoice_items.csv')
    clients  = read_csv('clients.csv')

    inv_data     = invoices[invoices['invoice_id'] == invoice_id].iloc[0]
    client_data  = clients[clients['client_id'] == inv_data['client_id']].iloc[0]
    invoice_items = items[items['invoice_id'] == invoice_id]

    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    # Header
    pdf.set_fill_color(30, 30, 80)
    pdf.rect(0, 0, 210, 40, 'F')
    pdf.set_font("helvetica", 'B', 28)
    pdf.set_text_color(255, 255, 255)
    pdf.set_y(10)
    pdf.cell(0, 20, text="INVOICE", align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.set_y(50)
    pdf.set_text_color(0, 0, 0)

    # Invoice meta
    pdf.set_font("helvetica", 'B', 11)
    pdf.cell(100, 8, text=f"Invoice #: {invoice_id}")
    pdf.cell(90, 8, text=f"Date: {inv_data['date']}", align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    if str(inv_data.get('due_date', '')) not in ['', 'nan']:
        pdf.cell(100, 8, text="")
        pdf.cell(90, 8, text=f"Due: {inv_data['due_date']}", align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.ln(5)
    pdf.set_font("helvetica", 'B', 12)
    pdf.cell(0, 8, text="BILL TO:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font("helvetica", size=11)
    pdf.cell(0, 7, text=str(client_data['name']), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 7, text=str(client_data['email']), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    if str(client_data.get('phone', '')) not in ['', 'nan']:
        pdf.cell(0, 7, text=str(client_data['phone']), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(8)

    # Table header
    pdf.set_fill_color(30, 30, 80)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("helvetica", 'B', 11)
    pdf.cell(95, 10, text="Description", border=1, fill=True)
    pdf.cell(25, 10, text="Qty", border=1, fill=True, align='C')
    pdf.cell(35, 10, text="Unit Price", border=1, fill=True, align='C')
    pdf.cell(35, 10, text="Total", border=1, fill=True, align='C', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    pdf.set_text_color(0, 0, 0)
    pdf.set_font("helvetica", size=10)
    fill = False
    for _, row in invoice_items.iterrows():
        pdf.set_fill_color(245, 245, 250)
        pdf.cell(95, 9, text=str(row['description']), border=1, fill=fill)
        pdf.cell(25, 9, text=str(int(row['quantity'])), border=1, fill=fill, align='C')
        pdf.cell(35, 9, text=f"${float(row['price']):.2f}", border=1, fill=fill, align='R')
        pdf.cell(35, 9, text=f"${float(row['line_total']):.2f}", border=1, fill=fill, align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        fill = not fill

    # Total
    pdf.ln(4)
    pdf.set_font("helvetica", 'B', 12)
    pdf.cell(155, 10, text="GRAND TOTAL:", align='R')
    pdf.set_fill_color(30, 30, 80)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(35, 10, text=f"${float(inv_data['total_amount']):.2f}", border=1, fill=True, align='R', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    if str(inv_data.get('notes', '')) not in ['', 'nan']:
        pdf.ln(8)
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("helvetica", 'I', 10)
        pdf.cell(0, 7, text=f"Notes: {inv_data['notes']}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

    # Status stamp
    pdf.set_y(-50)
    pdf.set_font("helvetica", 'B', 30)
    if inv_data['status'] == 'Paid':
        pdf.set_text_color(0, 160, 80)
    else:
        pdf.set_text_color(200, 50, 50)
    pdf.cell(0, 20, text=inv_data['status'].upper(), align='R')

    buf = io.BytesIO()
    pdf.output(buf)
    buf.seek(0)
    return send_file(buf, download_name=f"{invoice_id}.pdf", as_attachment=True, mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True)
