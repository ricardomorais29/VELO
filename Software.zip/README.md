# InvoiceFlow 🧾

A clean, web-based invoice tracking app built with Flask and Python.

## Features
- Dashboard with revenue analytics
- Client management (add, edit, delete)
- Invoice creation with line items
- Payment status tracking (Paid / Unpaid)
- PDF invoice generation & download
- Filter invoices by status

---

## 🚀 Quick Start (Local)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Open in browser
```
http://127.0.0.1:5000
```

Your data is saved in a `data/` folder as CSV files (auto-created on first run).

---

## 🌐 Deploy Online (Render — Free)

Render.com lets you host Flask apps for free.

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Initial InvoiceFlow app"
# Create a repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/invoice-app.git
git push -u origin main
```

### Step 2: Deploy on Render
1. Go to [render.com](https://render.com) and sign up
2. Click **New → Web Service**
3. Connect your GitHub repo
4. Set these settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Environment:** Python 3

5. Click **Deploy** — your app will be live in ~2 minutes!

---

## 🌐 Deploy Online (Railway — Alternative)

```bash
# Install Railway CLI
npm install -g @railway/cli

railway login
railway init
railway up
```

---

## File Structure
```
invoice_app/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── README.md
├── data/               # Auto-created CSV database
│   ├── clients.csv
│   ├── invoices.csv
│   └── invoice_items.csv
└── templates/          # HTML pages
    ├── base.html
    ├── dashboard.html
    ├── clients.html
    ├── client_form.html
    ├── invoices.html
    ├── invoice_form.html
    └── invoice_detail.html
```

---

## Notes
- Data is stored in CSV files in the `data/` folder
- For production, consider migrating to SQLite or PostgreSQL
- The app runs on port 5000 by default
